﻿using assignment;

List<SinhVien> list=new List<SinhVien>();
Service sv=new Service(list);
string path = @"D:\console\assignment\New Text Document.xml";
static int Menu()
{
    Console.WriteLine("mời nhập mục: ");
    int nhap=Convert.ToInt32(Console.ReadLine()); 
    return nhap;
}

void RunMenu()
{
    do
    {
        switch(Menu())
        {
            case 1:
                sv.Nhap();
                break;
            case 2:
                sv.Xuat();
                break;
            case 3:
                sv.Delete();
                break;
            case 5:
                sv.Them();
                break;
            case 6:
                Console.WriteLine("delegate: ");
                list lists = delegate (string name)
                {
                    Console.WriteLine($"ten: {name}");
                };
                lists("Công");
                break;
            case 4:
                sv.KTDinhDangSDT();
                break;
            case 7:
                sv.DocFile<SinhVien>(path);
                break;
            case 8:
                sv.GhiFile(path, list);
                break;
            case 9:
                sv.LinQ();
                break;
            case 0:
                System.Environment.Exit(0);
                break;
            default:
                Console.WriteLine("mời nhập lại");
                break;
        }
    }while(true);
}
Console.OutputEncoding=System.Text.Encoding.UTF8;
RunMenu();
public delegate void list(string name);
