var sp = document.getElementsByClassName('item');
for (var i = 0; i < sp.length; i++) {
    var item = sp[i];
    item.addEventListener('mouseover', showDes);
    item.addEventListener('mouseout', hideDes);
}

function showDes(event) {
    var item = event.target;
    var shopItem = item.parentElement.getElementsByClassName('icon')[0].style.display = "block";
}
function hideDes(event) {
    var item = event.target;
    var shopItem = item.parentElement.getElementsByClassName('icon')[0].style.display = "none";
}